There is no animation for sad and angry now, but you can tell from tears and fireballs.

Usage of Water Blocks:
Put Water_1 to the bottom left corner, and right click (or find it in instance list) -- creation code

	image_xscale 		to set how wide the water is (the number of the grids)
	image_yscale_max 	to set the height (the number of the grids * 32)
	fill_curr		to set initial water level (use a calculation of fill_min and fill_max)

Usage of Mirror:
In creation code, set target_x and target_y to destination Mirror (the coordinate of top grid of destination Mirror)